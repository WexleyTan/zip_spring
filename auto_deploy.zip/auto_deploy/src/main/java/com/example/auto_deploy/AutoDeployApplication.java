package com.example.auto_deploy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutoDeployApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutoDeployApplication.class, args);
	}

}
